lua54 'yes'

fx_version 'bodacious'
game 'gta5'
author 'Hyper_Pole'

this_is_a_map 'yes'

escrow_ignore {
  'stream/extra/*.ytyp',   -- Ignore all .yft files in any subfolder
  'stream/prop/*.ydr'   -- Ignore all .yft files in any subfolder
}
dependency '/assetpacks'